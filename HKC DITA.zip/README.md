# Get Started with DITA

Fork this repository to get started using DITA. 

The repository has example concept, task, and reference topics, as well as a DITA map that collections them in a signle document.
